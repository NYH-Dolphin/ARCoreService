﻿using UnityEngine;
using UnityEngine.UI;

public class iBeaconItemScript : MonoBehaviour
{
	public Text TextUUID;
	public Text TextRSSIValue;
	public Text TextAndroidSignalPower;
	public Text TextDistance;
	public Text TextiOSProximity;
	public int Num;
	//编号
	public Text TextX;
	public Text TextY;
	//坐标
}
