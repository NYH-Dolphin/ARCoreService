﻿using UnityEngine;
using UnityEngine.UI;

public class ScannedItemScript : MonoBehaviour
{
	public Text TextNameValue;
	public Text TextAddressValue;
	public Text TextRSSIValue;
}
