﻿// using DefaultNamespace;
// using LitJson;
// using UnityEngine;
//
// namespace NetworkTools
// {
//     public class SStartMessage : SendMessage
//     {
//         public bool start;
//         public string user;
//
//         public SStartMessage()
//         {
//             start = true;
//             user = GameManager.Instance.user;
//         }
//         
//
//         public override WWWForm ToWWWForm()
//         {
//             throw new System.NotImplementedException();
//         }
//     }
// }