﻿// using DefaultNamespace;
// using UnityEngine;
//
// namespace NetworkTools
// {
//     public class SEndMessage : SendMessage
//     {
//         public bool end;
//         public string user;
//
//         public SEndMessage()
//         {
//             end = true;
//             user = GameManager.Instance.user;
//         }
//         
//         public override WWWForm ToWWWForm()
//         {
//             throw new System.NotImplementedException();
//         }
//     }
// }