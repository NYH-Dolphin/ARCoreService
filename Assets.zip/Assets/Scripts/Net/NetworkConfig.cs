﻿namespace NetworkTools
{
    public class NetworkConfig
    {
        public static string IP = "127.0.0.1";
        public static string PORT = "8888";
    }
}