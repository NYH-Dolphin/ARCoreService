﻿using LitJson;

namespace NetworkTools
{
    public abstract class RecvMessage
    {
        
        public abstract void SetJsonData(JsonData data);
    }
}