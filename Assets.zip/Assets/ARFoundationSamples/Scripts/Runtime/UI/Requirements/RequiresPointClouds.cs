using UnityEngine.XR.ARSubsystems;

namespace UnityEngine.XR.ARFoundation.Samples
{
    public class RequiresPointClouds : RequiresARSubsystem<XRPointCloudSubsystem, XRPointCloudSubsystemDescriptor>
    { }
}
